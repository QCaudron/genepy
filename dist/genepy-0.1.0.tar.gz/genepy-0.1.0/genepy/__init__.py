# -*- coding: utf-8 -*-

__author__ = 'Quentin CAUDRON'
__email__ = 'quentincaudron@gmail.com'
__version__ = '0.1.0'

from seqarray import seqarray
